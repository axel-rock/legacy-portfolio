// Dynamic Content variables and sample values


// Dynamic Content variables and sample values
Enabler.setProfileId(10345818);
var devDynamicContent = {};

devDynamicContent.Eurosport__Australian_Open_2019_Feed= [{}];
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0]._id = 0;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].Unique_ID = 1;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].Reporting_Label = "test";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].Targeting_Column = "";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR1_TXT_1 = "KICK START YOUR DAY!";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR1_TXT_1_COLOR = "#0091d2";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR1_TXT_1_SIZE = 18;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR2_TXT_1 = "";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR2_TXT_1_COLOR = "#ffe23a";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR2_TXT_1_SIZE = 18;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR3_TXT_1 = "WITH GRAND SLAM TENNIS";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR3_TXT_1_COLOR = "#ffe23a";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR3_TXT_1_SIZE = 18;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR3_TXT_2 = "";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR3_TXT_2_COLOR = "#ffe23a";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR3_TXT_2_SIZE = 14;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR4_TXT_1 = "AUSTRALIAN OPEN";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR4_TXT_1_COLOR = "#ffe23a";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR4_TXT_1_SIZE = 18;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR4_TXT_2 = "ALL COURTS ALL MATCHES LIVE";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR4_TXT_2_COLOR = "#ffffff";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR4_TXT_2_SIZE = 10;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_1 = "\u00A39.99";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_1_COLOR = "#ffe23a";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_1_SIZE = 25;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_2 = "A MONTH<BR/>FOR 12 MONTH";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_2_COLOR = "#ffe23a";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_2_SIZE = 12;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_3 = "SUBSCRIBE";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_3_COLOR = "#ffe23a";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_3_SIZE = 9;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_4 = "\u00A359.88 TOTAL PRICE, INCL. VAT. T&CS APPLY. SUBSCRIPTION REQUIRED.<BR\/>AUTO RENEWS, UNLESS CANCELLED. MINIMUM TERM APPLIES.INTERNET CONNECTION REQUIRED.<BR\/>OFFER ONLY AVAILABLE IN THE UK.";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_4_COLOR = "#ffffff";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].FR5_TXT_4_SIZE = 5;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].ESPplayer_LT_logo = {};
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].ESPplayer_LT_logo.Type = "file";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].ESPplayer_LT_logo.Url = "https://s0.2mdn.net/preview/CgkIARDYyKTd_CwSGQCkoPPI9EC9kYU3yl8Afjf_8zsBrPfyhig/ads/richmedia/studio/60010769/60010769_20181220044651178_ESPplayer_LT_logo.png";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].ESPplayer_MG_logo = {};
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].ESPplayer_MG_logo.Type = "file";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].ESPplayer_MG_logo.Url = "https://s0.2mdn.net/preview/CgkIARCAg6nd_CwSGQCkoPPI3WLQOxV1hzKfly5AkkOuQpDr780/ads/richmedia/studio/60010769/60010769_20181220044656145_ESPplayer_MG_logo.png";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].END_COLOR = "#0091d2";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].Exit_URL = {};
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].Exit_URL.Url = "https://www.eurosport.fr";
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].Default = true;
devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].Active = true;
Enabler.setDevDynamicContent(devDynamicContent);

if (window.location.hostname == 'localhost' || window.location.hostname == '0.0.0.0' || window.location.hostname == 'rock.bzh') {
	devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].ESPplayer_LT_logo.Url = "../AO2019_PREevent-assets/" + Helper.getDimensions().width + "x" + Helper.getDimensions().height + "/ESPplayer_LT_logo.png";
	devDynamicContent.Eurosport__Australian_Open_2019_Feed[0].ESPplayer_MG_logo.Url = "../AO2019_PREevent-assets/" + Helper.getDimensions().width + "x" + Helper.getDimensions().height + "/ESPplayer_MG_logo.png";
}

Enabler.setDevDynamicContent(devDynamicContent);

if (!Enabler.isInitialized()) {
	Enabler.addEventListener(studio.events.StudioEvent.INIT, enablerInitialized);
} else {
	enablerInitialized();
}

function enablerInitialized() {
	if (window.location.hostname == 'localhost' || window.location.hostname == '0.0.0.0')
		init();
	else if (!Enabler.isVisible()) {
		Enabler.addEventListener(studio.events.StudioEvent.VISIBLE, init);
	} else {
		init();
	}
}

Helper.onClick = function() {
	Enabler.exitOverride("exit", dynamicContent.Eurosport__Australian_Open_2019_Feed[0].Exit);
}
